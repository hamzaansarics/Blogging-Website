﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using readingfacts.Datamodel;
using readingfacts.Models;
using readingfacts.Repository;
using System.IO;

namespace readingfacts.Controllers
{
    public class AdminController : Controller
    {
        private readonly IAdminRepo _repo;
        private readonly readingFContext _context;

        public AdminController(IAdminRepo repo, readingFContext context)
        {
            _repo = repo;
            _context = context;
        }

        public IActionResult articleposting(string result = "NULL")
        {
            ViewBag.Result = result;
            var data = new articleposting_model()
            {
                a_id = 0
            };
            return View(data);
        }
        [HttpPost]
        public async Task<IActionResult> articleposting(articleposting_model ap_obj,int iu_id)
        {
            if (ModelState.IsValid)
            {
                if (iu_id <= 0)
                {
                    var id = await _repo.Insert_Articles(ap_obj);
                    if (id == 1)
                    {
                        return RedirectToAction("articleposting", "Admin", new { result = "success" });
                    }
                    else
                    {
                        return RedirectToAction("articleposting", "Admin", new { result = "failure" });
                    }
                }
                else
                {
                    var ids=await _repo.update_articles(ap_obj, iu_id);
                    if (ids > 0)
                    {
                        return RedirectToAction("articleposting", "Admin", new { result = "updated" });
                    }
                   
                }
               
            }
            ViewBag.result = "null";
            var data = new articleposting_model()
            {
                a_id = 0
            };
            return View(data);
      
        }
        [HttpGet]
        public IActionResult update_articles(int id)
        {
            var data=_repo.update_articles(id);
            return View("articleposting", data);
        }
        [HttpGet]
        public async Task<IActionResult> delete_article(int id)
        {
            int res=await _repo.delete_article(id);
            if (res > 0)
            {
                return RedirectToAction("Index", "Home");
            }
            return RedirectToAction("Index", "Home");
        }
        [HttpPost]// This is Controller Action which is getting data
        public string Popular_Count(articleposting_model ap)
        {
            try 
            {
                if (ap.a_id == 0 || ap.a_category == null)
                {
                    return "Data is Not Inserted into DB";
                }
                else
                {
                    //var id = _context.popular_con.OrderBy(x => x.p_id==ap.a_id).SingleOrDefault();
                    var id = (from obj in _context.popular_con
                              where obj.art_id == ap.a_id
                              select obj.art_id).FirstOrDefault();
                    if (id.ToString() == null || id == 0)
                    {
                        var data = new popular_db()
                        {
                            art_id = ap.a_id,
                            category = ap.a_category,
                            clicked_count = 1,
                        };
                        _context.Add(data);
                        _context.SaveChanges();

                    }
                    else
                    {
                        var query = (from obj in _context.popular_con
                                     where obj.art_id == ap.a_id
                                     select obj).FirstOrDefault();

                        query.clicked_count += 1;
                        _context.Update(query);
                        _context.SaveChanges();
                    }


                }
                return "";
            }
            catch(Exception ex)
            {
                return ex.Message.ToString();
            }
            
        }

    }
}
