﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.InteropServices;

namespace readingfacts.Models
{
    public class articleposting_db
    {
        [Key]
        public int a_id { get; set; }
        public string? a_title { get; set; }
        public string? a_category { get; set; }
        public string? a_description { get; set; }
        public string? a_description_first { get; set; }
        public string? a_description_second { get; set; }
        public string? a_quotes_text { get; set; }
        public string? a_quotes_writer { get; set; }
        public string? a_imagepath { get; set; }
        public string? a_trend { get; set; }
        public DateTime? a_datetime { get; set; }
    }
}
