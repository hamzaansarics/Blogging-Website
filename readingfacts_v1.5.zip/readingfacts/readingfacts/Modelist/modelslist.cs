﻿using readingfacts.Datamodel;
using readingfacts.Models;

namespace readingfacts.Modelist
{
    public class modelslist
    {
        public List<articleposting_model> articleposting_trends { get; set; }
        public List<articleposting_model> articleposting_recents { get; set; }
        public List<articleposting_model> articleposting_cat_ls { get; set; }
        public List<articleposting_model> articleposting_cat_bzns { get; set; }
        public List<articleposting_model> articleposting_cat_tech { get; set; }
        public List<popular_model> popular_Model { get; set; }
        public List<int> ids_list { get; set; }
        public int count;
        public articleposting_model articleposting_model_obj;
       
        public string dt_formatter(DateTime? dt)
        {
            DateTime dt_now = DateTime.Now;
            TimeSpan diff1 = dt_now.Subtract((DateTime)dt);
            if (diff1.Days < 1)
            {
                if (diff1.Hours < 1)
                {
                    if (diff1.Minutes < 1)
                    {
                        return " "+diff1.Seconds.ToString()+" seconds ago";
                    }
                    return " " + diff1.Minutes.ToString() + " minutes ago";
                }
                return " " + diff1.Hours.ToString() + " hours ago";
            }

            return " "+dt?.ToString("dd MMMM yyyy");
        }

        public string string_slicer(string? val,int len)
        {
            if(val!=null && val!="")
            {
                var container = new List<string>();
                string words = "";
                for (int i = 0; i < val.Length; i++)
                {
                    if (val[i] != '.' && val[i] != ',' && val[i] != ' ')
                    {
                        words += val[i];
                    }
                    else
                    {
                        words += val[i];
                        container.Add(words);
                        words = "";
                    }

                }
                words = "";
                for (int i = 0; i < container.Count; i++)
                {
                    if (i < len)
                    {
                        words += container[i];
                    }
                    else
                    {
                        break;
                    }
                }
                return words;
            }
            else
            {
                return "";
            }
        }

    }
}
