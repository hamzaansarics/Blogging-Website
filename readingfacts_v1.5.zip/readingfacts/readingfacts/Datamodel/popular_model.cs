﻿namespace readingfacts.Datamodel
{
    public class popular_model
    {
        public int p_id { get; set; }
        public int art_id { get; set; }
        public int clicked_count { get; set; }
        public string category { get; set; }
    }
}
