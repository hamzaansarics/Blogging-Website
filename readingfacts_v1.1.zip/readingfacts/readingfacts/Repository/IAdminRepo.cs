﻿using readingfacts.Datamodel;
using readingfacts.Models;

namespace readingfacts.Repository
{
    public interface IAdminRepo
    {
        Task<int> Insert_Articles(articleposting_model ap_obj);
        public List<articleposting_model> Retrieve_Trending_Articles();
        public List<articleposting_model> Retrieve_Recent_Articles();
        List<articleposting_model> Retrieve_Catigorical_LS_Articles();
        List<articleposting_model> Retrieve_Catigorical_BZNS_Articles();
        List<articleposting_model> Retrieve_Catigorical_TECH_Articles();
        List<articleposting_model> dynamic_categories(string cat);
        articleposting_db retrieve_single_post(int id);
    }
}