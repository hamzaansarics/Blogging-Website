﻿using Microsoft.AspNetCore.Mvc;
using readingfacts.Datamodel;
using readingfacts.Modelist;
using readingfacts.Models;
using readingfacts.Repository;
using System.Diagnostics;

namespace readingfacts.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IAdminRepo _repo;

        public HomeController(ILogger<HomeController> logger,IAdminRepo repo)
        {
            _logger = logger;
            _repo = repo;
        }

        public IActionResult Index()
        {
            //var trends=_repo.Retrieve_Trending_Articles();
            //var recents = _repo.Retrieve_Recent_Articles();
            //var life_styles = _repo.Retrieve_Catigorical_LS_Articles();
            //var tech = _repo.Retrieve_Catigorical_TECH_Articles();
            //var bzns = _repo.Retrieve_Catigorical_BZNS_Articles();

            var trends = _repo.Retrieve_Dynamic_Articles("Trending");
            var recents = _repo.Retrieve_Dynamic_Articles("Recent");
            var life_styles = _repo.Retrieve_Dynamic_Articles("LifeStyles");
            var tech = _repo.Retrieve_Dynamic_Articles("Technology");
            var bzns = _repo.Retrieve_Dynamic_Articles("Business");
            var popular = _repo.popular_post();

            var obj = new modelslist()
            {
                articleposting_trends = trends,
                articleposting_recents = recents,
                articleposting_cat_bzns=bzns,
                articleposting_cat_tech=tech,
                articleposting_cat_ls=life_styles,
                popular_Model=popular,
            };
           
            return View(obj);
        }

        public IActionResult readingarticle(int id)
        {
            var rstp = _repo.retrieve_single_post(id);
            var ap_obj = _repo.dynamic_categories(rstp.a_category);
            var dyn_pp = _repo.dynamic_popular_post(rstp.a_category,"1");
            var obj = new articleposting_model()
            {
                a_id = rstp.a_id,
                a_category = rstp.a_category,
                a_datetime = rstp.a_datetime,
                a_path = rstp.a_imagepath,
                a_description_first = rstp.a_description_first,
                a_description_second = rstp.a_description_second,
                a_quotes_text = rstp.a_quotes_text,
                a_quotes_writer = rstp.a_quotes_writer,
                a_title = rstp.a_title,
                a_trend = rstp.a_trend,
            };
            var model = new modelslist()
            {
                articleposting_model_obj = obj,
                articleposting_trends = ap_obj,
                dynamic_popular_Model=dyn_pp,
            };
            return View(model);
        }
        public IActionResult trendingpost()
        {       
            return View();
        }
        public IActionResult lifestyle()
        {
            var lifestyles = _repo.Retrieve_Dynamic_Articles("LifeStyles");
            var dyn_pp = _repo.dynamic_popular_post("LifeStyles");
            var obj = new modelslist()
            {
                articleposting_cat_ls = lifestyles,
                dynamic_popular_Model = dyn_pp,
            };

            return View(obj);
        }

        public IActionResult technology()
        {
            var tech = _repo.Retrieve_Dynamic_Articles("Technology");
            var dyn_pp = _repo.dynamic_popular_post("Technology");
            var obj = new modelslist()
            {
                articleposting_cat_tech = tech,
                dynamic_popular_Model = dyn_pp,
            };

            return View(obj);
        }

        public IActionResult sports()
        {
            var sports = _repo.Retrieve_Dynamic_Articles("Sports");
            var dyn_pp = _repo.dynamic_popular_post("Sports");
            var obj = new modelslist()
            {
                articleposting_cat_sprt = sports,
                dynamic_popular_Model = dyn_pp,
            };

            return View(obj);
        }
        public IActionResult business()
        {
            var bzns = _repo.Retrieve_Dynamic_Articles("Business");
            var dyn_pp = _repo.dynamic_popular_post("Business");
            var obj = new modelslist()
            {
                articleposting_cat_bzns = bzns,
                dynamic_popular_Model = dyn_pp,
            };

            return View(obj);
        }
        public IActionResult world()
        {
            return View();
        }
        public IActionResult health()
        {

            var hlth = _repo.Retrieve_Dynamic_Articles("Health");
            var dyn_pp = _repo.dynamic_popular_post("Health");
            var obj = new modelslist()
            {
                articleposting_cat_hlth = hlth,
                dynamic_popular_Model = dyn_pp,
            };
            return View(obj);
        }
        public IActionResult science()
        {
            var scnc = _repo.Retrieve_Dynamic_Articles("Science");
            var dyn_pp = _repo.dynamic_popular_post("Science");
            var obj = new modelslist()
            {
                articleposting_cat_scnc = scnc,
                dynamic_popular_Model = dyn_pp,
            };
            return View(obj);

        }
        public IActionResult history()
        {
            var hist = _repo.Retrieve_Dynamic_Articles("History");
            var dyn_pp = _repo.dynamic_popular_post("History");
            var obj = new modelslist()
            {
                articleposting_cat_hist = hist,
                dynamic_popular_Model = dyn_pp,
            };

            return View(obj);
        }
        public IActionResult politics()
        {

            return View();
        }
        public IActionResult Contactus()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}