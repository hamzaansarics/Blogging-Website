﻿using System.ComponentModel.DataAnnotations;

namespace readingfacts.Datamodel
{
    public class articleposting_model
    {
        public int a_id { get; set; }
        [Required]
        public string? a_title { get; set; }
        [Required]
        public string? a_category { get; set; }
        
        public string? a_description { get; set; }
        [Required]
        public IFormFile a_image { get; set; }
        public string? a_path { get; set; }
        [Required]
        public string? a_trend { get; set; }
     
        [DataType(DataType.DateTime)]
        public DateTime? a_datetime { get; set; }
        [Required]
        public string? a_description_first { get; set; }
        [Required]
        public string? a_description_second { get; set; }
        public string? a_quotes_text { get; set; }
        public string? a_quotes_writer { get; set; }


    }
}
