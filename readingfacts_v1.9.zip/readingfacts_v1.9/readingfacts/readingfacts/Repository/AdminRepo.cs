﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using readingfacts.Datamodel;
using readingfacts.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace readingfacts.Repository
{
    public class AdminRepo : IAdminRepo
    {
        private readonly readingFContext _context;
        private readonly IWebHostEnvironment _env;
        public AdminRepo(readingFContext context,IWebHostEnvironment env)
        {
            _context = context;
            _env=env;
        }

        public async Task<int> Insert_Articles(articleposting_model ap_obj)
        {
            string path = null;
            if (ap_obj.a_image != null)
            {
                path = "images/";
                string fix_path = "";
                for(int i=0; i< ap_obj.a_image.FileName.Length; i++)
                { 
                    if (ap_obj.a_image.FileName[i]!=' ' && ap_obj.a_image.FileName[i] != '(' && ap_obj.a_image.FileName[i] != ')')
                    {
                        fix_path += ap_obj.a_image.FileName[i];
                    }
                }                
                //path += Guid.NewGuid().ToString() + "-" + ap_obj.a_image.FileName;
                path += Guid.NewGuid().ToString() + "-" + fix_path;
                string serverpath = Path.Combine(_env.WebRootPath, path);
                ap_obj.a_image.CopyTo(new FileStream(serverpath, FileMode.Create));
            }
            var data = new articleposting_db()
            {
                a_title=ap_obj.a_title,
                a_category=ap_obj.a_category,
                a_description_first=ap_obj.a_description_first,
                a_description_second=ap_obj.a_description_second,
                a_quotes_text=ap_obj.a_quotes_text,
                a_quotes_writer=ap_obj.a_quotes_writer,
                a_imagepath=path,
                a_trend=ap_obj.a_trend,
                a_datetime=DateTime.Now,
                
            };
            await _context.articleposting_con.AddAsync(data);
            int id = await _context.SaveChangesAsync();
            return id;

        }
        public articleposting_model update_articles(int? id)
        {
            var ap_obj = (from obj in _context.articleposting_con
                          where obj.a_id == id
                          select obj).FirstOrDefault();
            var data = new articleposting_model()
            {
                a_id = ap_obj.a_id,
                a_title = ap_obj.a_title,
                a_category = ap_obj.a_category,
                a_description_first = ap_obj.a_description_first,
                a_description_second = ap_obj.a_description_second,
                a_quotes_text = ap_obj.a_quotes_text,
                a_quotes_writer = ap_obj.a_quotes_writer,
                a_trend = ap_obj.a_trend,
            };
            return data;
        }
        public async Task<int> update_articles(articleposting_model ap_obj, int ids)
        {
            var art_pos =await _context.articleposting_con.FindAsync(ids);
            var path = "images/";
            string fix_path = "";
            for (int i = 0; i < ap_obj.a_image.FileName.Length; i++)
            {
                if (ap_obj.a_image.FileName[i] != ' ' && ap_obj.a_image.FileName[i] != '(' && ap_obj.a_image.FileName[i] != ')')
                {
                    fix_path += ap_obj.a_image.FileName[i];
                }
            }
            path += Guid.NewGuid().ToString() + "-" + fix_path;
            string serverpath = Path.Combine(_env.WebRootPath, path);
            ap_obj.a_image.CopyTo(new FileStream(serverpath, FileMode.Create));
            if (System.IO.File.Exists(art_pos.a_imagepath))
            {
                System.IO.File.Delete(art_pos.a_imagepath);
            }

            art_pos.a_title = ap_obj.a_title;
            art_pos.a_category = ap_obj.a_category;
            art_pos.a_description_first = ap_obj.a_description_first;
            art_pos.a_description_second = ap_obj.a_description_second;
            art_pos.a_quotes_text = ap_obj.a_quotes_text;
            art_pos.a_quotes_writer = ap_obj.a_quotes_writer;
            art_pos.a_imagepath = path;
            art_pos.a_trend = ap_obj.a_trend;
            _context.Update(art_pos);
            var id=await _context.SaveChangesAsync();
            return id;
        }
        public async Task<int> delete_article(int ids)
        {
            var model1 =await _context.articleposting_con.FindAsync(ids);
            var model2 = await _context.popular_con.FindAsync(ids);
            _context.Remove(model1);
            if (model2!=null)
            {
                _context.Remove(model2);
            }            
            int res=_context.SaveChanges();
            return res;
        }
        public List<articleposting_model> Retrieve_Trending_Articles()
        {
                var list = (from obj in _context.articleposting_con
                            where obj.a_trend=="true"
                            orderby obj.a_datetime descending
                            select obj).Take(6);

                var top6_trending = new List<articleposting_model>();
                foreach (var item in list)
                {
                    top6_trending.Add(new articleposting_model()
                    {
                        a_id=item.a_id,
                        a_title = item.a_title,
                        a_category = item.a_category,
                        a_description_first = item.a_description_first,
                        a_description_second = item.a_description_second,
                        a_quotes_text = item.a_quotes_text,
                        a_quotes_writer = item.a_quotes_writer,
                        a_trend = item.a_trend,
                        a_path=item.a_imagepath,
                        a_datetime = item.a_datetime,
                    });
                }

            return top6_trending;
        }

        public List<articleposting_model> Retrieve_Recent_Articles()
        {
            var list = (from obj in _context.articleposting_con
                        orderby obj.a_datetime descending
                        select obj).Take(6);

            var top6_recents = new List<articleposting_model>();
            foreach (var item in list)
            {
                top6_recents.Add(new articleposting_model()
                {
                    a_id = item.a_id,
    
                    a_title = item.a_title,
                    a_category = item.a_category,
                    a_description_first = item.a_description_first,
                    a_description_second = item.a_description_second,
                    a_quotes_text = item.a_quotes_text,
                    a_quotes_writer = item.a_quotes_writer,
                    a_trend = item.a_trend,
                    a_path = item.a_imagepath,
                    a_datetime=item.a_datetime,
                });
            }

            return top6_recents;
        }
        public List<articleposting_model> Retrieve_Catigorical_LS_Articles()
        {
            var list = (from obj in _context.articleposting_con
                        where obj.a_category=="LifeStyles"
                        orderby obj.a_datetime descending
                        select obj).Take(6);

            var top6_ls_categories = new List<articleposting_model>();
            foreach (var item in list)
            {
                top6_ls_categories.Add(new articleposting_model()
                {
                    a_id = item.a_id,
                    a_title = item.a_title,
                    a_category = item.a_category,
                    a_description_first = item.a_description_first,
                    a_description_second = item.a_description_second,
                    a_quotes_text = item.a_quotes_text,
                    a_quotes_writer = item.a_quotes_writer,
                    a_trend = item.a_trend,
                    a_path = item.a_imagepath,
                    a_datetime = item.a_datetime,

                });
            }

            return top6_ls_categories;
        }
        public List<articleposting_model> Retrieve_Catigorical_BZNS_Articles()
        {
            var list = (from obj in _context.articleposting_con
                        where obj.a_category == "Business"
                        orderby obj.a_datetime descending
                        select obj).Take(12);

            var top6_bzns_categories = new List<articleposting_model>();
            foreach (var item in list)
            {
                top6_bzns_categories.Add(new articleposting_model()
                {
                    a_id = item.a_id,
                    a_title = item.a_title,
                    a_category = item.a_category,
                    a_description_first = item.a_description_first,
                    a_description_second = item.a_description_second,
                    a_quotes_text = item.a_quotes_text,
                    a_quotes_writer = item.a_quotes_writer,
                    a_trend = item.a_trend,
                    a_path = item.a_imagepath,
                    a_datetime = item.a_datetime,

                });
            }

            return top6_bzns_categories;
        }
        public List<articleposting_model> Retrieve_Catigorical_TECH_Articles()
        {
            var list = (from obj in _context.articleposting_con
                        where obj.a_category == "Technology"
                        orderby obj.a_datetime descending
                        select obj).Take(6);

            var top6_tech_categories = new List<articleposting_model>();
            foreach (var item in list)
            {
                top6_tech_categories.Add(new articleposting_model()
                {
                    a_id = item.a_id,
                    a_title = item.a_title,
                    a_category = item.a_category,
                    a_description_first = item.a_description_first,
                    a_description_second = item.a_description_second,
                    a_quotes_text = item.a_quotes_text,
                    a_quotes_writer = item.a_quotes_writer,
                    a_trend = item.a_trend,
                    a_path = item.a_imagepath,
                    a_datetime = item.a_datetime,

                });
            }

            return top6_tech_categories;
        }

        public List<articleposting_model> dynamic_categories(string cat)
        {
            var list = (from obj in _context.articleposting_con
                        where obj.a_category == cat
                        orderby obj.a_datetime descending
                        select obj).Take(12);

            var top6_tech_categories = new List<articleposting_model>();
            foreach (var ap_obj in list)
            {
                top6_tech_categories.Add(new articleposting_model()
                {
                    a_id = ap_obj.a_id,
                    a_title = ap_obj.a_title,
                    a_category = ap_obj.a_category,
                    a_description_first = ap_obj.a_description_first,
                    a_description_second = ap_obj.a_description_second,
                    a_quotes_text = ap_obj.a_quotes_text,
                    a_quotes_writer = ap_obj.a_quotes_writer,             
                    a_trend = ap_obj.a_trend,
                    a_datetime = ap_obj.a_datetime,
                    a_path = ap_obj.a_imagepath,

                });
            }

            return top6_tech_categories;
        }
        public articleposting_db retrieve_single_post(int id)
        {
            var stp = _context.articleposting_con.Find(id);
               
;           return stp;
        }
       public List<articleposting_model> popular_post()
       {
            var total = (from obj1 in _context.popular_con
                         select obj1).Count();
            var list1 = (from obj1 in _context.popular_con
                       //  where obj1.dt_now.Day==DateTime.Now.Day-1
                         orderby obj1.clicked_count descending
                         select obj1).Take(total);

            var id_data = new List<int>();
            foreach(var dd in list1)
            {
                id_data.Add(dd.art_id);
            }
           
            var popular_12 = new List<articleposting_model>();
            foreach (var data in id_data)
            {
                var ap_obj = (from obj5 in _context.articleposting_con
                              where obj5.a_id==data
                              select obj5).FirstOrDefault();

                popular_12.Add(new articleposting_model()
                {
                    a_id = ap_obj.a_id,
                    a_title = ap_obj.a_title,
                    a_category = ap_obj.a_category,
                    a_description_first = ap_obj.a_description_first,
                    a_description_second = ap_obj.a_description_second,
                    a_quotes_text = ap_obj.a_quotes_text,
                    a_quotes_writer = ap_obj.a_quotes_writer,
                    a_trend = ap_obj.a_trend,
                    a_datetime = ap_obj.a_datetime,
                    a_path = ap_obj.a_imagepath,

                });
            }
            return popular_12;
        }


    }
}
