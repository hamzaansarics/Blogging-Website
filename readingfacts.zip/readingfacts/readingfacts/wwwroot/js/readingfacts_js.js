﻿//This func is used to get data from top input box by id with ajax
function getdatafromview()
{

    var id = $("#categor_y").val();
 
    alert(id);
    //This will make single object of our all values there is one important thig the left side of name property should be matched with our model class property which we are using to pass data as ID:id
   
}
function retrieve(obj_data) {
    $.ajax({
        url: "/Home/JDataPost",
        method: "post",//this is post type bcz we are posting data to db
        data: obj_data,//this is data object get from top func and input
        success: function (data) {
            //if successful then this message will pop up on alert box
            alert(“successful Data”);
        },
        error: function (error) {
            console.log(error)
        }
    })
}