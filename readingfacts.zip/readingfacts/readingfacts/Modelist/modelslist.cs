﻿using readingfacts.Datamodel;
using readingfacts.Models;

namespace readingfacts.Modelist
{
    public class modelslist
    {
        public List<articleposting_model> articleposting_trends { get; set; }
        public List<articleposting_model> articleposting_recents { get; set; }
        public List<articleposting_model> articleposting_cat_ls { get; set; }
        public List<articleposting_model> articleposting_cat_bzns { get; set; }
        public List<articleposting_model> articleposting_cat_tech { get; set; }
        public List<popular_model> popular_Model { get; set; }
        public List<int> ids_list { get; set; }
        
        public int count;
       
    }
}
