﻿using Microsoft.AspNetCore.Mvc;
using readingfacts.Modelist;
using readingfacts.Models;
using readingfacts.Repository;
using System.Diagnostics;

namespace readingfacts.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IAdminRepo _repo;

        public HomeController(ILogger<HomeController> logger,IAdminRepo repo)
        {
            _logger = logger;
            _repo = repo;
        }

        public IActionResult Index()
        {
            var trends=_repo.Retrieve_Trending_Articles();
            var recents = _repo.Retrieve_Recent_Articles();
            var life_styles = _repo.Retrieve_Catigorical_LS_Articles();
            var tech = _repo.Retrieve_Catigorical_TECH_Articles();
            var bzns = _repo.Retrieve_Catigorical_BZNS_Articles();

            var obj = new modelslist()
            {
                articleposting_trends = trends,
                articleposting_recents = recents,
                articleposting_cat_bzns=bzns,
                articleposting_cat_tech=tech,
                articleposting_cat_ls=life_styles,
            };
           
            return View(obj);
        }

        public IActionResult d_trending_post(int id)
        {
            var rstp=_repo.retrieve_single_trending_post(id);
            return View(rstp);
        }

        public IActionResult Contactus()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}