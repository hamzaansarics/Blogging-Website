
(function ($) {

    "use strict";
	
	// ACCORDIAN
	if(isExists('[data-accordian]')){
		$('[data-accordian]').on('click', function(){
			
			var $this = $(this),
				accordianBody = $this.data('accordian');
			
			$(this).find('i').toggleClass('ion-minus').toggleClass('ion-plus');
			$(accordianBody).toggleClass('active');
			
			return false;
		});
	}
	
	// SEARCH AREA
	if(isExists('.src-btn')){
		
		var srcBtn = $('.src-btn');
		var srcIcn = $('.src-icn');
		var closeIcn = $('.close-icn');
		var srcForm = $('.src-form');
		
		srcBtn.on('click', function(){
			
			$(srcIcn).toggleClass('active');
			$(closeIcn).toggleClass('active');
			$(srcForm).toggleClass('active');
			
		});
	}
	
	
	// RESIZABLE IMAGES
	if(isExists('.responsive-img-bg')){
		
		$('.responsive-img-bg .p-item').each(function(){
			
			var $this = $(this),
				imgSrc = $this.find('img').attr('src');
			
			$this.css({'background-image': 'url('+imgSrc+')'});
		});		
	}
	
	
	// ISOTOPE
	
	$(window).on('load', function(){
		
		// ISOTOPE PORTFOLIO WITH FILTER
		if(isExists('.p-grid-isotope')){
			$('.p-grid-isotope').isotope({
				// set itemSelector so .grid-sizer is not used in layout
				itemSelector: '.p-item',
				percentPosition: true,
				masonry: {
					columnWidth: '.grid-sizer', 
					
				},
			})
		 
		}
	
	});
	
	// DROPDOWN MENU
	
	var winWidth = $(window).width();
	dropdownMenu(winWidth);
	
	$(window).on('resize', function(){
		winWidth = $(window).width();
		dropdownMenu(winWidth);
		
	});
	
	// REVOLUTION SLIDER
	
	if(isExists('#rev_slider_28_1')){
		var tpj=jQuery;
		var revapi28;
		
		if(tpj("#rev_slider_28_1").revolution == undefined){
			revslider_showDoubleJqueryError("#rev_slider_28_1");
		}else{
			revapi28 = tpj("#rev_slider_28_1").show().revolution({
				sliderType:"standard",
				jsFileLocation:"revolution/js/",
				sliderLayout:"fullscreen",
				dottedOverlay:"none",
				delay:15000,
				
				navigation: {
					
					keyboardNavigation:"off",
					keyboard_direction: "horizontal",
					mouseScrollNavigation:"off",
					mouseScrollReverse:"default",
					onHoverStop:"off",
					arrows: {
						style:"uranus",
						enable:true,
						hide_onmobile:false,
						hide_onleave:false,
						tmp:'',
						left: {
							h_align:"left",
							v_align:"center",
							h_offset:20,
							v_offset:0
						},
						right: {
							h_align:"right",
							v_align:"center",
							h_offset:20,
							v_offset:0
						}
					}
					,
					bullets: {
						enable:true,
						hide_onmobile:false,
						style:"hermes",
						hide_onleave:false,
						direction:"horizontal",
						h_align:"center",
						v_align:"bottom",
						h_offset:0,
						v_offset:20,
						space:5,
						tmp:''
					}
				},
				responsiveLevels:[1240,1024,778,480],
				visibilityLevels:[1240,1024,778,480],
				gridwidth:[1240,1024,778,480],
				gridheight:[868,768,960,720],
				lazyType:"none",
				
				shadow:0,
				spinner:"off",
				stopLoop:"off",
				stopAfterLoops:-1,
				stopAtSlide:-1,
				
				shuffle:"off",
				autoHeight:"off",
				fullScreenAutoWidth:"off",
				fullScreenAlignForce:"off",
				fullScreenOffsetContainer: "",
				fullScreenOffset: "60px",
				hideThumbsOnMobile:"off",
				hideSliderAtLimit:0,
				hideCaptionAtLimit:0,
				hideAllCaptionAtLilmit:0,
				debugMode:false,
				fallbacks: {
					simplifyAll:"off",
					nextSlideOnWindowFocus:"off",
					disableFocusListener:false,
				}
			});
		}
	}
	
				
	$('[data-menu]').on('click', function(){
		
		var mainMenu = $(this).data('menu');
		
		$(mainMenu).toggleClass('visible-menu');
		
	});
	
	if(isExists('.venobox')){
		$('.venobox').attr('data-gall', 'gallery').venobox({
			framewidth: '50%',        // default: ''
			frameheight: '',       // default: ''
			border: '0px',             // default: '0'
			bgcolor: '#5dff5e',         // default: '#fff'
			titleattr: 'data-title',    // default: 'title'
			numeratio: false,            // default: false
			infinigall: true            // default: false
		}); 

	}
	
	
})(jQuery);


function dropdownMenu(winWidth){
	
	if(winWidth > 767){
		
		$('.main-menu li.drop-down').on('mouseover', function(){
			var $this = $(this),
				menuAnchor = $this.children('a');
				
			menuAnchor.addClass('mouseover');
			
		}).on('mouseleave', function(){
			var $this = $(this),
				menuAnchor = $this.children('a');
				
			menuAnchor.removeClass('mouseover');
		});
		
	}else{
		
		$('.main-menu li.drop-down > a').on('click', function(){
			
			if($(this).attr('href') == '#') return false;
			if($(this).hasClass('mouseover')){ $(this).removeClass('mouseover'); }
			else{ $(this).addClass('mouseover'); }
			return false;
		});
	}
	
}

function isExists(elem){
	if ($(elem).length > 0) { 
		return true;
	}
	return false;
}
function getdatafromview1() {
	var id1 = document.getElementById("a_id1").innerText;  
	var category1 = document.getElementById("categor_y1").innerText;
	//alert(id1);
	var obj = {
		a_id: id1,
		a_category: category1,	
	};
	retrieve(obj);
};
function getdatafromview2() {
	var id2 = document.getElementById("a_id2").innerText;
	var category2 = document.getElementById("categor_y2").innerText;
	//alert(id2);
	var obj = {
		a_id: id2,
		a_category: category2,
	};
	retrieve(obj);
};
function getdatafromview3() {
	var id3 = document.getElementById("a_id3").innerText;
	var category3 = document.getElementById("categor_y3").innerText;
	//alert(id3);
	var obj = {
		a_id: id3,
		a_category: category3,
	};
	retrieve(obj);
};
function getdatafromview4() {
	var id4 = document.getElementById("a_id4").innerText;
	var category4 = document.getElementById("categor_y4").innerText;
	//alert(id4);
	var obj = {
		a_id: id4,
		a_category: category4,
	};
	retrieve(obj);
};
function getdatafromview5() {
	var id5 = document.getElementById("a_id5").innerText;
	var category5 = document.getElementById("categor_y5").innerText;
	//alert(id5);
	var obj = {
		a_id: id5,
		a_category: category5,
	};
	retrieve(obj);
};
function getdatafromview6() {
	var id6 = document.getElementById("a_id6").innerText;
	var category6 = document.getElementById("categor_y6").innerText;
	//alert(id6);
	var obj = {
		a_id: id6,
		a_category: category6,
	};
	retrieve(obj);
};
function getdatafromview7() {
	var id7 = document.getElementById("a_id7").innerText;
	var category7 = document.getElementById("categor_y7").innerText;
	//alert(id7);
	var obj = {
		a_id: id7,
		a_category: category7,
	};
	retrieve(obj);
};
function getdatafromview8() {
	
	var id8 = 0;
	var category8 = "";
	id8 = document.getElementById("a_id8").innerText;
	category8 = document.getElementById("categor_y8").innerText;

	const myElements = document.getElementById("a_id8");
	for (let i = 0; i < myElements.length; i++) {
		const elementText = myElements[i].textContent;
		alert(elementText); // This will output the text content of each element with the class name "myClass"
	}



	
	var obj = {
		a_id: id8,
		a_category: category8,
	};
	retrieve(obj);
};
function getdatafromview9() {
	var id9 = document.getElementById("a_id9").innerText;
	var category9 = document.getElementById("categor_y9").innerText;
	//alert(id9);
	var obj = {
		a_id: id9,
		a_category: category9,
	};
	retrieve(obj);
};
function getdatafromview10() {
	var id10 = document.getElementById("a_id10").innerText;
	var category10 = document.getElementById("categor_y10").innerText;
	//alert(id10);
	var obj = {
		a_id: id10,
		a_category: category10,
	};
	retrieve(obj);
};
function getdatafromview11() {
	var id11 = document.getElementById("a_id11").innerText;
	var category11 = document.getElementById("categor_y11").innerText;
	//alert(id11);
	var obj = {
		a_id: id11,
		a_category: category11,
	};
	retrieve(obj);
};
function getdatafromview12() {
	var id12 = document.getElementById("a_id12").innerText;
	var category12 = document.getElementById("categor_y12").innerText;
	//alert(id12);
	var obj = {
		a_id: id12,
		a_category: category12,
	};
	retrieve(obj);
};
function getdatafromview13() {
	var id13 = document.getElementById("a_id13").innerText;
	var category13 = document.getElementById("categor_y13").innerText;
	//alert(id13);
	var obj = {
		a_id: id13,
		a_category: category13,
	};
	retrieve(obj);
};
function getdatafromview14() {
	var id14 = document.getElementById("a_id14").innerText;
	var category14 = document.getElementById("categor_y14").innerText;
	//alert(id14);
	var obj = {
		a_id: id14,
		a_category: category14,
	};
	retrieve(obj);
};
function getdatafromview15() {
	var id15 = document.getElementById("a_id15").innerText;
	var category15 = document.getElementById("categor_y15").innerText;
	//alert(id15);
	var obj = {
		a_id: id15,
		a_category: category15,
	};
	retrieve(obj);
};

function getdatafromview16() {
	var id16 = document.getElementById("a_id16").innerText;
	var category16 = document.getElementById("categor_y16").innerText;
	//alert(id16);
	var obj = {
		a_id: id16,
		a_category: category16,
	};
	retrieve(obj);
};
function getdatafromview17() {
	var id17 = document.getElementById("a_id17").innerText;
	var category17 = document.getElementById("categor_y17").innerText;
	//alert(id17);
	var obj = {
		a_id: id17,
		a_category: category17,
	};
	retrieve(obj);
};
function getdatafromview18() {
	var id18 = document.getElementById("a_id18").innerText;
	var category18 = document.getElementById("categor_y18").innerText;
	//alert(id18);
	var obj = {
		a_id: id18,
		a_category: category18,
	};
	retrieve(obj);
};
function getdatafromview19() {
	var id19 = document.getElementById("a_id19").innerText;
	var category19 = document.getElementById("categor_y19").innerText;
	//alert(id19);
	var obj = {
		a_id: id19,
		a_category: category19,
	};
	retrieve(obj);
};
function retrieve(obj_data) {
	$.ajax({
		type: "POST",
		url: "/Admin/Popular_Count",
		data: obj_data,
		success: function (data) {
			alert("Success");
		},
		error: function (error) {
			alert("Failed to Get Data");
		}
	});
}
