﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using readingfacts.Models;
using readingfacts.Repository;

namespace readingfacts.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAccountRepo _repos;
        public  AccountController(IAccountRepo repos)
        {
            _repos = repos;
        }

       
        [HttpGet]
        public async Task<IActionResult> signin(string returnUrl)
        {
            return View();
        }

       
        [HttpPost]
        public async Task<IActionResult> signin(SignInUserModel login, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                var result = await _repos.signinuser(login);
                if (result.Succeeded)
                {
                    if (!string.IsNullOrEmpty(returnUrl))
                    {
                        return LocalRedirect(returnUrl);
                    }
                    return RedirectToAction("Index", "Home");

                }
                ModelState.AddModelError("", "Your Credential is Invalid Please try Valid oNe");
                return View();

            }
            ModelState.AddModelError("", "Put all the Essentials Credentials");
            return View();
        }
        public async Task<IActionResult> signup()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> signup(SignUpUserModel su)
        {
            if (ModelState.IsValid)
            {
                var result = await _repos.signup(su);
                if (result.Succeeded)
                {
                    return RedirectToAction("Index", "Home");
                }
                ModelState.AddModelError("", "Failed to Create you Account, Please! try again");
                return View();

            }
            ModelState.AddModelError("", "Your Inputs is Invalid for Sign Up try Valid oNe");
            return View();
        }
        
        public async Task<IActionResult> logout(string returnUrl)
        {
            await _repos.logout();
            return LocalRedirect(returnUrl);
        }

    }
}
