﻿using Microsoft.AspNetCore.Identity;
using readingfacts.Models;

namespace readingfacts.Repository
{
    public interface IAccountRepo
    {
        Task<SignInResult> signinuser(SignInUserModel sin);
        Task<IdentityResult> signup(SignUpUserModel sm);
         Task logout();
    }
}