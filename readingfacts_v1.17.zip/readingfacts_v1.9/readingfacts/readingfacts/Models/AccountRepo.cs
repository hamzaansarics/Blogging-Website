﻿using Microsoft.AspNetCore.Identity;
using readingfacts.Models;
namespace readingfacts.Repository
{
    public class AccountRepo : IAccountRepo
    {

        private readonly UserManager<ApplicationUser> _user;

        private readonly SignInManager<ApplicationUser> _login;
        public AccountRepo(UserManager<ApplicationUser> user, SignInManager<ApplicationUser> login)
        {
            _user = user;
            _login = login;
        }


        public async Task<IdentityResult> signup(SignUpUserModel sm)
        {
            var userinfo = new ApplicationUser()
            {
                firstname=sm.firstname,
                lastname=sm.lastname,
                UserName = sm.username,
                Email = sm.email,
               
            };
            var data = await _user.CreateAsync(userinfo, sm.password);
            return data;
        }

        public async Task<SignInResult> signinuser(SignInUserModel sin)
        {
            var result = await _login.PasswordSignInAsync(sin.username, sin.password, sin.rememberme, false);
            return result;
        }

        public async Task logout()
        {
            await _login.SignOutAsync();          
        }


    }
}
