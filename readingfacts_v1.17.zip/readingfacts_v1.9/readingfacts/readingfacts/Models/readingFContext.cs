﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace readingfacts.Models
{
    public class readingFContext: IdentityDbContext<ApplicationUser>
    {
        public readingFContext(DbContextOptions<readingFContext> options) : base(options)
        {
        }
        public DbSet<articleposting_db> articleposting_con { get; set; } //this is table name in our db
        public DbSet<popular_db> popular_con { get; set; } //this is table name in our db

    }
}
