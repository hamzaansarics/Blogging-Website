﻿using System.ComponentModel.DataAnnotations;

namespace readingfacts.Models
{
    public class SignInUserModel
    {

    
        public string username { get; set; }
        public string password { get; set; }
        public bool rememberme { get; set; }

    }
}
