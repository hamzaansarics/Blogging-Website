﻿using System.ComponentModel.DataAnnotations;

namespace readingfacts.Models
{
    public class SignUpUserModel
    {
        [Required]
        public string firstname { get; set; }
        [Required]
        public string lastname { get; set; }
      
        public string username { get; set; }
        [Required]
        public string email { get; set; }
        [Required]
        public string password { get; set; }
        [Required]
        [Compare(nameof(password), ErrorMessage = "Passwords do not match")]
        public string conf_password { get; set; }

    }
}
