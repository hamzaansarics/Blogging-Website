﻿using Microsoft.AspNetCore.Identity;

namespace readingfacts.Models
{
    public class ApplicationUser:IdentityUser
    {
        public string firstname { get; set; }
        public string lastname { get; set; }

    }
}
