﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace readingfacts.Migrations
{
    public partial class new_changes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "a_description_first",
                table: "articleposting_con",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "a_description_second",
                table: "articleposting_con",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "a_quotes_text",
                table: "articleposting_con",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "a_quotes_writer",
                table: "articleposting_con",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "a_description_first",
                table: "articleposting_con");

            migrationBuilder.DropColumn(
                name: "a_description_second",
                table: "articleposting_con");

            migrationBuilder.DropColumn(
                name: "a_quotes_text",
                table: "articleposting_con");

            migrationBuilder.DropColumn(
                name: "a_quotes_writer",
                table: "articleposting_con");
        }
    }
}
