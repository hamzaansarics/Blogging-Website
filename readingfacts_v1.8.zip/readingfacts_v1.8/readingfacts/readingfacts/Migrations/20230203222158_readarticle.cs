﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace readingfacts.Migrations
{
    public partial class readarticle : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "articleposting_con",
                columns: table => new
                {
                    a_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    a_title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    a_category = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    a_description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    a_imagepath = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    a_trend = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    a_datetime = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_articleposting_con", x => x.a_id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "articleposting_con");
        }
    }
}
