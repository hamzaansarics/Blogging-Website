﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using readingfacts.Datamodel;
using readingfacts.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace readingfacts.Repository
{
    public class AdminRepo : IAdminRepo //version 1.9
    {
        private readonly readingFContext _context;
        private readonly IWebHostEnvironment _env;
        public AdminRepo(readingFContext context,IWebHostEnvironment env)
        {
            _context = context;
            _env=env;
        }

        public async Task<int> Insert_Articles(articleposting_model ap_obj)
        {
            string path = null;
            if (ap_obj.a_image != null)
            {
                path = "images/";
                string fix_path = "";
                for(int i=0; i< ap_obj.a_image.FileName.Length; i++)
                { 
                    if (ap_obj.a_image.FileName[i]!=' ' && ap_obj.a_image.FileName[i] != '(' && ap_obj.a_image.FileName[i] != ')')
                    {
                        fix_path += ap_obj.a_image.FileName[i];
                    }
                }                
                //path += Guid.NewGuid().ToString() + "-" + ap_obj.a_image.FileName;
                path += Guid.NewGuid().ToString() + "-" + fix_path;
                string serverpath = Path.Combine(_env.WebRootPath, path);
                ap_obj.a_image.CopyTo(new FileStream(serverpath, FileMode.Create));
            }
            var data = new articleposting_db()
            {
                a_title=ap_obj.a_title,
                a_category=ap_obj.a_category,
                a_description_first=ap_obj.a_description_first,
                a_description_second=ap_obj.a_description_second,
                a_quotes_text=ap_obj.a_quotes_text,
                a_quotes_writer=ap_obj.a_quotes_writer,
                a_imagepath=path,
                a_trend=ap_obj.a_trend,
                a_datetime=DateTime.Now,
                
            };
            await _context.articleposting_con.AddAsync(data);
            int id = await _context.SaveChangesAsync();
            return id;

        }
        public articleposting_model update_articles(int? id)
        {
            var ap_obj = (from obj in _context.articleposting_con
                          where obj.a_id == id
                          select obj).FirstOrDefault();
            var data = new articleposting_model()
            {
                a_id = ap_obj.a_id,
                a_title = ap_obj.a_title,
                a_category = ap_obj.a_category,
                a_description_first = ap_obj.a_description_first,
                a_description_second = ap_obj.a_description_second,
                a_quotes_text = ap_obj.a_quotes_text,
                a_quotes_writer = ap_obj.a_quotes_writer,
                a_trend = ap_obj.a_trend,
            };
            return data;
        }
        public async Task<int> update_articles(articleposting_model ap_obj, int ids)
        {
            var art_pos =await _context.articleposting_con.FindAsync(ids);
            var path = "images/";
            string fix_path = "";
            for (int i = 0; i < ap_obj.a_image.FileName.Length; i++)
            { 
                if (ap_obj.a_image.FileName[i] != ' ' && ap_obj.a_image.FileName[i] != '(' && ap_obj.a_image.FileName[i] != ')')
                {
                    fix_path += ap_obj.a_image.FileName[i];
                }
            }
            path += Guid.NewGuid().ToString() + "-" + fix_path;
            string serverpath = Path.Combine(_env.WebRootPath, path);
            ap_obj.a_image.CopyTo(new FileStream(serverpath, FileMode.Create));
            if (System.IO.File.Exists("wwwroot/" + art_pos.a_imagepath))
            {
                System.IO.File.Delete("wwwroot/" + art_pos.a_imagepath);
            }
            art_pos.a_title = ap_obj.a_title;
            art_pos.a_category = ap_obj.a_category;
            art_pos.a_description_first = ap_obj.a_description_first;
            art_pos.a_description_second = ap_obj.a_description_second;
            art_pos.a_quotes_text = ap_obj.a_quotes_text;
            art_pos.a_quotes_writer = ap_obj.a_quotes_writer;
            art_pos.a_imagepath = path;
            art_pos.a_trend = ap_obj.a_trend;
            _context.Update(art_pos);
            var id=await _context.SaveChangesAsync();
           
            return id;
        }
       
        public async Task<int> delete_article(int ids)
        {
            var model1 =await _context.articleposting_con.FindAsync(ids);
            var model2 = await _context.popular_con.FindAsync(ids);
            _context.Remove(model1);
            if (model2!=null)
            {
                _context.Remove(model2);
            }            
            int res=_context.SaveChanges();
            return res;
        }
        public List<articleposting_model> Retrieve_Dynamic_Articles(string filter)
        {
            if (filter == "Trending")
            {
                var list = (from obj in _context.articleposting_con
                            where obj.a_trend == "true"
                            orderby obj.a_datetime descending
                            select obj).Take(6);

                var articles = new List<articleposting_model>();
                foreach (var item in list)
                {
                    articles.Add(new articleposting_model()
                    {
                        a_id = item.a_id,
                        a_title = item.a_title,
                        a_category = item.a_category,
                        a_description_first = item.a_description_first,
                        a_description_second = item.a_description_second,
                        a_quotes_text = item.a_quotes_text,
                        a_quotes_writer = item.a_quotes_writer,
                        a_trend = item.a_trend,
                        a_path = item.a_imagepath,
                        a_datetime = item.a_datetime,
                    });
                }

                return articles;
            }
            else if (filter == "Recent")
            {
                var list = (from obj in _context.articleposting_con
                            orderby obj.a_datetime descending
                            select obj).Take(6);

                var articles = new List<articleposting_model>();
                foreach (var item in list)
                {
                    articles.Add(new articleposting_model()
                    {
                        a_id = item.a_id,

                        a_title = item.a_title,
                        a_category = item.a_category,
                        a_description_first = item.a_description_first,
                        a_description_second = item.a_description_second,
                        a_quotes_text = item.a_quotes_text,
                        a_quotes_writer = item.a_quotes_writer,
                        a_trend = item.a_trend,
                        a_path = item.a_imagepath,
                        a_datetime = item.a_datetime,
                    });
                }

                return articles;
            }
            else
            {
                var list = (from obj in _context.articleposting_con
                            where obj.a_category == filter
                            orderby obj.a_datetime descending
                            select obj).Take(6);

                var articles = new List<articleposting_model>();
                foreach (var item in list)
                {
                    articles.Add(new articleposting_model()
                    {
                        a_id = item.a_id,
                        a_title = item.a_title,
                        a_category = item.a_category,
                        a_description_first = item.a_description_first,
                        a_description_second = item.a_description_second,
                        a_quotes_text = item.a_quotes_text,
                        a_quotes_writer = item.a_quotes_writer,
                        a_trend = item.a_trend,
                        a_path = item.a_imagepath,
                        a_datetime = item.a_datetime,

                    });
                }

                return articles;
            }
            var articles1 = new List<articleposting_model>();
            return articles1;

        }
      
        public List<articleposting_model> dynamic_categories(string cat)
        {
            var list = (from obj in _context.articleposting_con
                        where obj.a_category == cat
                        orderby obj.a_datetime descending
                        select obj).Take(12);

            var top6_tech_categories = new List<articleposting_model>();
            foreach (var ap_obj in list)
            {
                top6_tech_categories.Add(new articleposting_model()
                {
                    a_id = ap_obj.a_id,
                    a_title = ap_obj.a_title,
                    a_category = ap_obj.a_category,
                    a_description_first = ap_obj.a_description_first,
                    a_description_second = ap_obj.a_description_second,
                    a_quotes_text = ap_obj.a_quotes_text,
                    a_quotes_writer = ap_obj.a_quotes_writer,             
                    a_trend = ap_obj.a_trend,
                    a_datetime = ap_obj.a_datetime,
                    a_path = ap_obj.a_imagepath,

                });
            }

            return top6_tech_categories;
        }
        public articleposting_db retrieve_single_post(int id)
        {
            var stp = _context.articleposting_con.Find(id);              
;           return stp;
        }
       public List<articleposting_model> popular_post()
        {
            var list1 = (from ap in _context.articleposting_con
                        join pp in _context.popular_con
                        on ap.a_id equals pp.art_id                    
                        orderby pp.clicked_count descending
                        select ap).Take(6);

            var popular_12 = new List<articleposting_model>();
            foreach (var ap_obj in list1)
            {
                
                popular_12.Add(new articleposting_model()
                {
                    a_id = ap_obj.a_id,
                    a_title = ap_obj.a_title,
                    a_category = ap_obj.a_category,
                    a_description_first = ap_obj.a_description_first,
                    a_description_second = ap_obj.a_description_second,
                    a_quotes_text = ap_obj.a_quotes_text,
                    a_quotes_writer = ap_obj.a_quotes_writer,
                    a_trend = ap_obj.a_trend,
                    a_datetime = ap_obj.a_datetime,
                    a_path = ap_obj.a_imagepath,

                });
            }
            return popular_12;
        }
        public List<articleposting_model> dynamic_popular_post(string cat_)
        {
            var list1 = from ap in _context.articleposting_con
                        join pp in _context.popular_con
                        on ap.a_id equals pp.art_id
                        where ap.a_category ==cat_
                        orderby pp.clicked_count descending
                        select ap;
           
            var dyn_popular = new List<articleposting_model>();
            foreach (var ap_obj in list1)
            {             
                    dyn_popular.Add(new articleposting_model()
                    {
                        a_id = ap_obj.a_id,
                        a_title = ap_obj.a_title,
                        a_category = ap_obj.a_category,
                        a_description_first = ap_obj.a_description_first,
                        a_description_second = ap_obj.a_description_second,
                        a_quotes_text = ap_obj.a_quotes_text,
                        a_quotes_writer = ap_obj.a_quotes_writer,
                        a_trend = ap_obj.a_trend,
                        a_datetime = ap_obj.a_datetime,
                        a_path = ap_obj.a_imagepath,

                    });
                
            }
            return dyn_popular;
        }


    }
}
